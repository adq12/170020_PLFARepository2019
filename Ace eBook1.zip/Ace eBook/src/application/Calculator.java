package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

public class Calculator{
	String opd1="";
	String opd2="";
	String res;
	double ab=5;
	double bc=10;
	
	Button add=new Button("Add");
	TextField rollno=new TextField();
	TextField operand1= new TextField();
	TextField operand2= new TextField();
	TextField result= new TextField();
	
	
	
	public Calculator(Stage programstage) {
	Pane theRoot1 = new Pane(); // defining the object for the pane
	programstage.setTitle("Calculator");

	// define the attributes for the USer Interface

rollno.setLayoutX(400);
rollno.setLayoutX(200);

operand1.setLayoutX(200);
operand1.setLayoutY(200);

operand2.setLayoutX(200);
operand2.setLayoutX(400);

result.setLayoutX(200);
result.setLayoutX(600);

add.setLayoutX(200);
add.setLayoutX(800);
add.setOnAction(event->{
	Add();
});


		
	
	
	// add all the necessary elements in the pane 
	theRoot1.getChildren().addAll(operand1,operand2,result,add,rollno);

	Scene scene = new Scene(theRoot1, 1200, 700); // define the height and width of the scene
	programstage.setScene(scene); 
	programstage.show();
	}



	private void Add() {
		opd1=operand1.getText();
		opd2=operand2.getText();
		if(opd1!=null && opd2!=null) {
			
		res=opd1+opd2;
		result.setText(res);
		}
		else { 
			opd1="0";
			opd2="0";
			res=opd1+opd2;
			result.setText(res);					
		}
		
		
	}




  


	
}

